Aws.add_service(:DataPipeline, {
  api: "#{Aws::API_DIR}/datapipeline/2012-10-29/api-2.json",
  docs: "#{Aws::API_DIR}/datapipeline/2012-10-29/docs-2.json",
  paginators: "#{Aws::API_DIR}/datapipeline/2012-10-29/paginators-1.json",
})
