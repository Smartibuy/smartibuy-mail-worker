Aws.add_service(:ImportExport, {
  api: "#{Aws::API_DIR}/importexport/2010-06-01/api-2.json",
  docs: "#{Aws::API_DIR}/importexport/2010-06-01/docs-2.json",
  paginators: "#{Aws::API_DIR}/importexport/2010-06-01/paginators-1.json",
})
