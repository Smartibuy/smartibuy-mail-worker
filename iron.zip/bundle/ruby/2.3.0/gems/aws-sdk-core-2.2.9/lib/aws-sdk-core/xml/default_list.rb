module Aws
  module Xml
    # @api private
    class DefaultList < Array

      alias nil? empty?

    end
  end
end
