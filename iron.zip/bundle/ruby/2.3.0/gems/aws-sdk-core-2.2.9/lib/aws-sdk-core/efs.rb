Aws.add_service(:EFS, {
  api: "#{Aws::API_DIR}/elasticfilesystem/2015-02-01/api-2.json",
  docs: "#{Aws::API_DIR}/elasticfilesystem/2015-02-01/docs-2.json",
})
