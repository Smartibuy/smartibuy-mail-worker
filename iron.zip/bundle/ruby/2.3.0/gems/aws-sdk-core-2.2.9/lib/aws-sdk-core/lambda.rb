Aws.add_service(:Lambda, {
  api: "#{Aws::API_DIR}/lambda/2015-03-31/api-2.json",
  docs: "#{Aws::API_DIR}/lambda/2015-03-31/docs-2.json",
  paginators: "#{Aws::API_DIR}/lambda/2015-03-31/paginators-1.json",
})
