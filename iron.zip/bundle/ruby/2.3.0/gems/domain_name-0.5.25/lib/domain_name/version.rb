class DomainName
  VERSION = "0.5.25"
end
