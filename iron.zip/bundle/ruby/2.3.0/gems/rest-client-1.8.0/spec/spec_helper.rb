require 'webmock/rspec'
require 'restclient'
