module Aws
  module SQS

    autoload :QueuePoller, 'aws-sdk-resources/services/sqs/queue_poller'

  end
end
