module Aws
  module SNS

    autoload :MessageVerifier, 'aws-sdk-resources/services/sns/message_verifier'

  end
end
