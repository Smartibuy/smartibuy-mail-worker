# -*- ruby encoding: utf-8 -*-

require 'mime/types'
